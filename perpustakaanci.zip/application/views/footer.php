<!-- start footer -->
<div class="page-footer">
    <div class="page-footer-inner"> <?= date('Y') ?> &copy; Perpustakaan UMP
    </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>
<!-- end footer -->
</div>

<!-- Sweet Alert -->
<script src="<?= base_url() ?>assets/sweet-alert/sweetalert.min.js"></script>
<script src="<?= base_url() ?>assets/sweet-alert/sweet-alert-data.js"></script>
<!-- start js include path -->
<script src="<?= base_url() ?>assets/jquery.min.js"></script>
<script src="<?= base_url() ?>assets/popper/popper.js"></script>
<script src="<?= base_url() ?>assets/jquery.blockui.min.js"></script>
<script src="<?= base_url() ?>assets/jquery.slimscroll.js"></script>
<!-- data tables -->
<script src="<?= base_url() ?>assets/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>assets/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js"></script>
<script src="<?= base_url() ?>assets/table_data.js"></script>
<!-- bootstrap -->
<script src="<?= base_url() ?>assets/bootstrap/js/bootstrap.min.js"></script>
<script src="<?= base_url() ?>assets/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<!-- counterup -->
<script src="<?= base_url() ?>assets/counterup/jquery.waypoints.min.js"></script>
<script src="<?= base_url() ?>assets/counterup/jquery.counterup.min.js"></script>
<!-- Common js-->
<script src="<?= base_url() ?>assets/app.js"></script>
<script src="<?= base_url() ?>assets/layout.js"></script>
<script src="<?= base_url() ?>assets/theme-color.js"></script>
<!-- material -->
<script src="<?= base_url() ?>assets/material/material.min.js"></script>
<!-- chart js -->
<script src="<?= base_url() ?>assets/chart-js/Chart.bundle.js"></script>
<script src="<?= base_url() ?>assets/chart-js/utils.js"></script>
<script src="<?= base_url() ?>assets/chart-js/home-data.js"></script>
<!--select2-->
<script src="<?= base_url() ?>assets/select2/js/select2.js"></script>
<script src="<?= base_url() ?>assets/select2/js/select2-init.js"></script>
<!-- end js include path -->

</html>